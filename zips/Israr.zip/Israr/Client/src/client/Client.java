/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 *
 * @author tnpham
 */
public class Client {

    public static void main(String[] args) {
        DatagramSocket socket;
        InetAddress address;
 
        byte[] buf;
        try {
            socket = new DatagramSocket();
            byte[] host = {(byte)192, (byte)168, (byte)43, (byte)171};
            address = InetAddress.getByAddress(host);//192.168.15.226
            
            String msg = "Test";
            
            buf = msg.getBytes();
            DatagramPacket packet = new DatagramPacket(buf, buf.length, address, 8888);
            socket.send(packet);
            packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);
            String received = new String(packet.getData(), 0, packet.getLength());
            System.out.println(received);
            socket.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    } 
}
